﻿using System;
using System.IO;

namespace ContabilidadGerencial
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Contabilidad Gerencial");
            Console.WriteLine("--------------------");

            while (true)
            {
                Console.WriteLine("1. Crear Transacción");
                Console.WriteLine("2. Leer Transacciones");
                Console.WriteLine("3. Actualizar Transacción");
                Console.WriteLine("4. Borrar Transacción");
                Console.WriteLine("5. Salir");

                Console.Write("Elija una opción: ");
                int opcion = Convert.ToInt32(Console.ReadLine());

                switch (opcion)
                {
                    case 1:
                        CrearTransaccion();
                        break;
                    case 2:
                        LeerTransacciones();
                        break;
                    case 3:
                        ActualizarTransaccion();
                        break;
                    case 4:
                        BorrarTransaccion();
                        break;
                    case 5:
                        Environment.Exit(0);
                        break;
                    default:
                        Console.WriteLine("Opción inválida");
                        break;
                }
            }
        }

        static void CrearTransaccion()
        {
            Console.Write("Ingrese fecha (aaaa-mm-dd): ");
            string fecha = Console.ReadLine();

            Console.Write("Ingrese tipo (Ingreso/Egreso): ");
            string tipo = Console.ReadLine();

            Console.Write("Ingrese monto: ");
            double monto = Convert.ToDouble(Console.ReadLine());

            string archivo = $"Transaccion_{fecha}.txt";
            using (StreamWriter escritor = File.CreateText(archivo))
            {
                escritor.WriteLine($"{fecha},{tipo},{monto}");
            }

            Console.WriteLine("Transacción creada exitosamente!");
        }

        static void LeerTransacciones()
        {
            string[] archivos = Directory.GetFiles("Transacciones");

            foreach (string archivo in archivos)
            {
                using (StreamReader lector = File.OpenText(archivo))
                {
                    string linea = lector.ReadLine();
                    string[] partes = linea.Split(',');
                    Console.WriteLine($"Fecha: {partes[0]}, Tipo: {partes[1]}, Monto: {partes[2]}");
                }
            }
        }

        static void ActualizarTransaccion()
        {
            Console.Write("Ingrese fecha (aaaa-mm-dd): ");
            string fecha = Console.ReadLine();

            Console.Write("Ingrese nuevo tipo (Ingreso/Egreso): ");
            string tipo = Console.ReadLine();

            Console.Write("Ingrese nuevo monto: ");
            double monto = Convert.ToDouble(Console.ReadLine());

            string archivo = $"Transaccion_{fecha}.txt";
            using (StreamWriter escritor = File.CreateText(archivo))
            {
                escritor.WriteLine($"{fecha},{tipo},{monto}");
            }

            Console.WriteLine("Transacción actualizada exitosamente!");
        }

        static void BorrarTransaccion()
        {
            Console.Write("Ingrese fecha (aaaa-mm-dd): ");
            string fecha = Console.ReadLine();

            string archivo = $"Transaccion_{fecha}.txt";
            if (File.Exists(archivo))
            {
                File.Delete(archivo);
                Console.WriteLine("Transacción eliminada exitosamente!");
            }
            else
            {
                Console.WriteLine("Transacción no encontrada");
            }
        }
    }
}

