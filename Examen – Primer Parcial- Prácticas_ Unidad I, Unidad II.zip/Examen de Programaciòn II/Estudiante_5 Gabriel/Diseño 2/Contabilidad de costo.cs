﻿using System;
using System.IO;

class ContabilidadCostos
{
    static string filePath = "contabilidad_costos.txt";

    static void Main(string[] args)
    {
        while (true)
        {
            Console.WriteLine("Seleccione una opción:");
            Console.WriteLine("1. Crear registro");
            Console.WriteLine("2. Leer registros");
            Console.WriteLine("3. Actualizar registro");
            Console.WriteLine("4. Borrar registro");
            Console.WriteLine("5. Salir");
            Console.Write("Opción: ");
            int opcion = Convert.ToInt32(Console.ReadLine());

            switch (opcion)
            {
                case 1:
                    CrearRegistro();
                    break;
                case 2:
                    LeerRegistros();
                    break;
                case 3:
                    ActualizarRegistro();
                    break;
                case 4:
                    BorrarRegistro();
                    break;
                case 5:
                    Environment.Exit(0);
                    break;
                default:
                    Console.WriteLine("Opción no válida. Intente de nuevo.");
                    break;
            }
        }
    }

    static void CrearRegistro()
    {
        Console.WriteLine("Ingrese los datos del nuevo registro:");
        Console.Write("Fecha: ");
        string fecha = Console.ReadLine();
        Console.Write("Descripción: ");
        string descripcion = Console.ReadLine();
        Console.Write("Monto: ");
        decimal monto = Convert.ToDecimal(Console.ReadLine());

        using (StreamWriter writer = new StreamWriter(filePath, true))
        {
            writer.WriteLine($"{fecha},{descripcion},{monto}");
        }

        Console.WriteLine("Registro creado exitosamente.");
    }

    static void LeerRegistros()
    {
        Console.WriteLine("Registros de contabilidad de costos:");
        using (StreamReader reader = new StreamReader(filePath))
        {
            string line;
            while ((line = reader.ReadLine()) != null)
            {
                Console.WriteLine(line);
            }
        }
    }

    static void ActualizarRegistro()
    {
        Console.WriteLine("Ingrese el número de línea del registro que desea actualizar:");
        int numLinea = Convert.ToInt32(Console.ReadLine());
        Console.WriteLine("Ingrese los nuevos datos del registro:");
        Console.Write("Fecha: ");
        string fecha = Console.ReadLine();
        Console.Write("Descripción: ");
        string descripcion = Console.ReadLine();
        Console.Write("Monto: ");
        decimal monto = Convert.ToDecimal(Console.ReadLine());

        string[] lines = File.ReadAllLines(filePath);
        if (numLinea > 0 && numLinea <= lines.Length)
        {
            lines[numLinea - 1] = $"{fecha},{descripcion},{monto}";
            File.WriteAllLines(filePath, lines);
            Console.WriteLine("Registro actualizado exitosamente.");
        }
        else
        {
            Console.WriteLine("Número de línea fuera de rango.");
        }
    }

    static void BorrarRegistro()
    {
        Console.WriteLine("Ingrese el número de línea del registro que desea borrar:");
        int numLinea = Convert.ToInt32(Console.ReadLine());

        string[] lines = File.ReadAllLines(filePath);
        if (numLinea > 0 && numLinea <= lines.Length)
        {
            string[] newLines = new string[lines.Length - 1];
            int j = 0;
            for (int i = 0; i < lines.Length; i++)
            {
                if (i != numLinea - 1)
                {
                    newLines[j] = lines[i];
                    j++;
                }
            }
            File.WriteAllLines(filePath, newLines);
            Console.WriteLine("Registro borrado exitosamente.");
        }
        else
        {
            Console.WriteLine("Número de línea fuera de rango.");
        }
    }
}

