﻿using System;
using System.IO;
using System.Threading;

public class Program
{
    public static void Main()
    {
        Console.WriteLine("Ingrese los datos del registro:");
        Console.Write("Nombre: ");
        string nombre = Console.ReadLine();
        Console.Write("Cantidad: ");
        decimal cantidad;

        // Validar la entrada del usuario
        while (!decimal.TryParse(Console.ReadLine(), out cantidad))
        {
            Console.WriteLine("Cantidad inválida. Ingrese nuevamente:");
            Console.Write("Cantidad: ");
        }

        // Crear un hilo para la escritura del registro en el archivo
        Thread thread = new Thread(() =>
        {
            try
            {
                using (StreamWriter writer = new StreamWriter("registros.txt", true))
                {
                    writer.WriteLine($"{nombre},{cantidad}");
                }

                Console.WriteLine("Registro creado exitosamente.");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error al crear el registro: {ex.Message}");
            }
        });

        // Iniciar el hilo
        thread.Start();

        // Esperar a que el hilo termine antes de salir del programa
        thread.Join();
    }
}

