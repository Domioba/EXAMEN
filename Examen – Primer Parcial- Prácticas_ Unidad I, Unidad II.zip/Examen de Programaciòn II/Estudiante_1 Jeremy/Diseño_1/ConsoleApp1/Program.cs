﻿using System;
using System.IO;
using System.Threading;

class EstadoResultados
{
    static string path = @"EstadoResultados.txt";

    static void Main(string[] args)
    {
        Thread t1 = new Thread(MostrarMenu);
        t1.Start();
        t1.Join();

        Thread t2 = new Thread(CrearEstadoResultados);
        t2.Start();
        t2.Join();

        Thread t3 = new Thread(MostrarEstadoResultados);
        t3.Start();
        t3.Join();

        Thread t4 = new Thread(ActualizarEstadoResultados);
        t4.Start();
        t4.Join();

        Thread t5 = new Thread(EliminarEstadoResultados);
        t5.Start();
        t5.Join();
    }

    static void MostrarMenu()
    {
        Console.WriteLine("Seleccione una opción:");
        Console.WriteLine("1. Crear estado de resultados");
        Console.WriteLine("2. Mostrar estado de resultados");
        Console.WriteLine("3. Actualizar estado de resultados");
        Console.WriteLine("4. Eliminar estado de resultados");
        Console.WriteLine("5. Salir");

        int opcion = int.Parse(Console.ReadLine());

        switch (opcion)
        {
            case 1:
                CrearEstadoResultados();
                break;
            case 2:
                MostrarEstadoResultados();
                break;
            case 3:
                ActualizarEstadoResultados();
                break;
            case 4:
                EliminarEstadoResultados();
                break;
            case 5:
                Console.WriteLine("Saliendo del programa...");
                Environment.Exit(0);
                break;
            default:
                Console.WriteLine("Opción no válida. Inténtelo de nuevo.");
                break;
        }
    }
    static void CrearEstadoResultados()
    {
        
        // Ingresar datos desde el teclado
        Console.WriteLine("Ingrese los ingresos por ventas:");
        double ingresosVentas = double.Parse(Console.ReadLine());

        Console.WriteLine("Ingrese el costo de los productos vendidos:");
        double costoProductosVendidos = double.Parse(Console.ReadLine());

        Console.WriteLine("Ingrese los gastos operativos:");
        double gastosOperativos = double.Parse(Console.ReadLine());

        Console.WriteLine("Ingrese los ingresos no operativos:");
        double ingresosNoOperativos = double.Parse(Console.ReadLine());

        Console.WriteLine("Ingrese los gastos no operativos:");
        double gastosNoOperativos = double.Parse(Console.ReadLine());

        // Calcular beneficios
        double beneficioBruto = ingresosVentas - costoProductosVendidos;
        double beneficioOperativo = beneficioBruto - gastosOperativos;
        double beneficioNeto = beneficioOperativo + ingresosNoOperativos - gastosNoOperativos;

        // Guardar el estado de resultados en un archivo
        using (StreamWriter writer = File.CreateText(path))
        {
            writer.WriteLine("Estado de Resultados");
            writer.WriteLine("Ingresos por ventas: $" + ingresosVentas);
            writer.WriteLine("Costo de los productos vendidos: $" + costoProductosVendidos);
            writer.WriteLine("Gastos operativos: $" + gastosOperativos);
            writer.WriteLine("Ingresos no operativos: $" + ingresosNoOperativos);
            writer.WriteLine("Gastos no operativos: $" + gastosNoOperativos);
            writer.WriteLine("Beneficio bruto: $" + beneficioBruto);
            writer.WriteLine("Beneficio operativo: $" + beneficioOperativo);
            writer.WriteLine("Beneficio neto: $" + beneficioNeto);
        }

        Console.WriteLine("El estado de resultados ha sido creado y guardado en el archivo 'EstadoResultados.txt'.");
        MostrarMenu();

    }

    static void MostrarEstadoResultados()
    {
        // El código para mostrar el estado de resultados sigue siendo el mismo
        if (File.Exists(path))
        {
            string[] lines = File.ReadAllLines(path);
            foreach (string line in lines)
            {
                Console.WriteLine(line);
            }
        }
        else
        {
            Console.WriteLine("No se ha creado ningún estado de resultados.");
        }

        MostrarMenu();

    }

    static void ActualizarEstadoResultados()
    {
        // El código para actualizar el estado de resultados sigue siendo el mismo
        if (File.Exists(path))
        {
            Console.WriteLine("El estado de resultados existente será reemplazado.");
            CrearEstadoResultados();
        }
        else
        {
            Console.WriteLine("No hay ningún estado de resultados para actualizar. Cree uno nuevo.");
            CrearEstadoResultados();
        }
    }

    static void EliminarEstadoResultados()
    {
        // El código para eliminar el estado de resultados sigue siendo el mismo
        if (File.Exists(path))
        {
            File.Delete(path);
            Console.WriteLine("El estado de resultados ha sido eliminado.");
        }
        else
        {
            Console.WriteLine("No hay ningún estado de resultados para eliminar.");
        }

        MostrarMenu();
    }
}.
