﻿using System;
using System.IO;

class ContabilidadCostos
{
    static string filePath = "contabilidad_costos.txt";

    static void Main(string[] args)
    {
        while (true)
        {
            Console.WriteLine("Seleccione una opción:");
            Console.WriteLine("1. Crear registro");
            Console.WriteLine("2. Leer registros");
            Console.WriteLine("3. Actualizar registro");
            Console.WriteLine("4. Borrar registro");
            Console.WriteLine("5. Salir");
            Console.Write("Opción: ");
            int opcion;
            if (!int.TryParse(Console.ReadLine(), out opcion))
            {
                Console.WriteLine("Opción no válida. Intente de nuevo.");
                continue;
            }

            switch (opcion)
            {
                case 1:
                    CrearRegistro();
                    break;
                case 2:
                    LeerRegistros();
                    break;
                case 3:
                    ActualizarRegistro();
                    break;
                case 4:
                    BorrarRegistro();
                    break;
                case 5:
                    Environment.Exit(0);
                    break;
                default:
                    Console.WriteLine("Opción no válida. Intente de nuevo.");
                    break;
            }
        }
    }

    static void CrearRegistro()
    {
        try
        {
            Console.WriteLine("Ingrese los datos del nuevo registro:");
            Console.Write("Fecha: ");
            string fecha = Console.ReadLine();
            Console.Write("Descripción: ");
            string descripcion = Console.ReadLine();
            Console.Write("Monto: ");
            decimal monto;
            if (!decimal.TryParse(Console.ReadLine(), out monto))
            {
                Console.WriteLine("Monto no válido. Intente de nuevo.");
                return;
            }

            using (StreamWriter writer = new StreamWriter(filePath, true))
            {
                writer.WriteLine($"{fecha},{descripcion},{monto}");
            }

            Console.WriteLine("Registro creado exitosamente.");
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Error al crear el registro: {ex.Message}");
        }
    }

    static void LeerRegistros()
    {
        try
        {
            Console.WriteLine("Registros de contabilidad de costos:");
            using (StreamReader reader = new StreamReader(filePath))
            {
                string line;
                while ((line = reader.ReadLine()) != null)
                {
                    Console.WriteLine(line);
                }
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Error al leer los registros: {ex.Message}");
        }
    }

    static void ActualizarRegistro()
    {
        try
        {
            Console.WriteLine("Ingrese el número de línea del registro que desea actualizar:");
            int numLinea;
            if (!int.TryParse(Console.ReadLine(), out numLinea))
            {
                Console.WriteLine("Número de línea no válido. Intente de nuevo.");
                return;
            }

            string[] lines = File.ReadAllLines(filePath);
            if (numLinea > 0 && numLinea <= lines.Length)
            {
                Console.WriteLine("Ingrese los nuevos datos del registro:");
                Console.Write("Fecha: ");
                string fecha = Console.ReadLine();
                Console.Write("Descripción: ");
                string descripcion = Console.ReadLine();
                Console.Write("Monto: ");
                decimal monto;
                if (!decimal.TryParse(Console.ReadLine(), out monto))
                {
                    Console.WriteLine("Monto no válido. Intente de nuevo.");
                    return;
                }

                lines[numLinea - 1] = $"{fecha},{descripcion},{monto}";
                File.WriteAllLines(filePath, lines);
                Console.WriteLine("Registro actualizado exitosamente.");
            }
            else
            {
                Console.WriteLine("Número de línea fuera de rango.");
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Error al actualizar el registro: {ex.Message}");
        }
    }

    static void BorrarRegistro()
    {
        try
        {
            Console.WriteLine("Ingrese el número de línea del registro que desea borrar:");
            int numLinea;
            if (!int.TryParse(Console.ReadLine(), out numLinea))
            {
                Console.WriteLine("Número de línea no válido. Intente de nuevo.");
                return;
            }

            string[] lines = File.ReadAllLines(filePath);
            if (numLinea > 0 && numLinea <= lines.Length)
            {
                string[] newLines = new string[lines.Length - 1];
                int j = 0;
                for (int i = 0; i < lines.Length; i++)
                {
                    if (i != numLinea - 1)
                    {
                        newLines[j] = lines[i];
                        j++;
                    }
                }
                File.WriteAllLines(filePath, newLines);
                Console.WriteLine("Registro borrado exitosamente.");
            }
            else
            {
                Console.WriteLine("Número de línea fuera de rango.");
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Error al borrar el registro: {ex.Message}");
        }
    }
}
