﻿using System;
using System.IO;
using System.Threading;

class Program
{
    static void Main(string[] args)
    {
        // Solicitar al usuario que ingrese los datos del artículo
        Console.WriteLine("Ingrese los datos del artículo:");
        Console.Write("Nombre del artículo: ");
        string nombreArticulo = Console.ReadLine();

        Console.Write("Cantidad producida: ");
        int cantidadProducida = Convert.ToInt32(Console.ReadLine());

        Console.Write("Costo total de insumos: ");
        decimal costoTotalInsumos = Convert.ToDecimal(Console.ReadLine());

        Console.Write("Costo de mano de obra directa: ");
        decimal manoDeObraDirecta = Convert.ToDecimal(Console.ReadLine());

        Console.Write("Costos indirectos de fabricación: ");
        decimal costosIndirectosFabricacion = Convert.ToDecimal(Console.ReadLine());

        Console.Write("Horas laborales requeridas para la producción: ");
        decimal horasLaborales = Convert.ToDecimal(Console.ReadLine());

        Console.Write("Costo por hora laboral: ");
        decimal costoHoraLaboral = Convert.ToDecimal(Console.ReadLine());

        // Crear e iniciar los hilos
        Thread t = new Thread(() => metedohilo1(nombreArticulo, costoTotalInsumos, manoDeObraDirecta, costosIndirectosFabricacion, cantidadProducida));
        t.Start();
        t.Join();

        Thread t2 = new Thread(() => metedohilo2(horasLaborales, costoHoraLaboral, costosIndirectosFabricacion, cantidadProducida));
        t2.Start();
        t2.Join();

        Thread t3 = new Thread(() => metedohilo3(nombreArticulo, costoTotalInsumos, manoDeObraDirecta, costosIndirectosFabricacion, cantidadProducida));
        t3.Start();
        t3.Join();

        // Solicitar al usuario que realice operaciones CRUD o salir del programa
        bool salir = false;
        while (!salir)
        {
            Console.WriteLine("\nSeleccione una opción:");
            Console.WriteLine("1. Actualizar cantidad producida");
            Console.WriteLine("2. Borrar el artículo");
            Console.WriteLine("3. Salir");
            Console.Write("Ingrese el número de opción: ");
            int opcion = Convert.ToInt32(Console.ReadLine());

            switch (opcion)
            {
                case 1:
                    Console.Write("Ingrese la nueva cantidad producida: ");
                    int nuevaCantidadProducida = Convert.ToInt32(Console.ReadLine());
                    ActualizarCantidadProducida("resultados.txt", nuevaCantidadProducida);
                    Console.WriteLine("Cantidad producida actualizada correctamente.");
                    break;
                case 2:
                    BorrarArticulo("resultados.txt");
                    Console.WriteLine("Artículo eliminado correctamente.");
                    break;
                case 3:
                    salir = true;
                    Console.WriteLine("Saliendo del programa...");
                    break;
                default:
                    Console.WriteLine("Opción no válida.");
                    break;
            }
        }

        Console.ReadLine();
    }

    static void metedohilo1(string nombreArticulo, decimal costoTotalInsumos, decimal manoDeObraDirecta, decimal costosIndirectosFabricacion, int cantidadProducida)
    {
        decimal costoPromedio = CalcularCostoPromedio(costoTotalInsumos, manoDeObraDirecta, costosIndirectosFabricacion, cantidadProducida);
        Console.WriteLine($"El costo total del artículo '{nombreArticulo}' usando el método de costo promedio es: {costoPromedio:C}");
    }

    static void metedohilo2(decimal horasLaborales, decimal costoHoraLaboral, decimal CIF, int cantidad)
    {
        decimal costoEstandar = CalcularCostoEstandar(horasLaborales, costoHoraLaboral, CIF, cantidad);
        Console.WriteLine($"El costo total del artículo usando el método de costo estándar es: {costoEstandar:C}");
    }

    static void metedohilo3(string nombreArticulo, decimal costoTotalInsumos, decimal manoDeObraDirecta, decimal costosIndirectosFabricacion, int cantidadProducida)
    {
        GuardarResultadosEnArchivo(nombreArticulo, costoTotalInsumos, manoDeObraDirecta, costosIndirectosFabricacion, cantidadProducida);
    }

    static decimal CalcularCostoPromedio(decimal costoInsumos, decimal manoDeObra, decimal CIF, int cantidad)
    {
        // Costo total
        decimal costoTotal = costoInsumos + manoDeObra + CIF;

        // Costo promedio por unidad
        decimal costoPromedio = costoTotal / cantidad;

        return costoPromedio;
    }

    static decimal CalcularCostoEstandar(decimal horasLaborales, decimal costoHoraLaboral, decimal CIF, int cantidad)
    {
        // Costo directo de la mano de obra
        decimal costoManoDeObra = horasLaborales * costoHoraLaboral;

        // Costo total
        decimal costoTotal = costoManoDeObra + CIF;

        // Costo estándar por unidad
        decimal costoEstandar = costoTotal / cantidad;

        return costoEstandar;
    }

    static void GuardarResultadosEnArchivo(string nombreArticulo, decimal costoTotalInsumos, decimal manoDeObraDirecta, decimal costosIndirectosFabricacion, int cantidadProducida)
    {
        // Utilizando FileStream para escribir en un archivo
        using (FileStream fileStream = new FileStream("resultados.txt", FileMode.Create))
        {
            using (StreamWriter writer = new StreamWriter(fileStream))
            {
                decimal costoPromedio = CalcularCostoPromedio(costoTotalInsumos, manoDeObraDirecta, costosIndirectosFabricacion, cantidadProducida);
                writer.WriteLine($"Artículo: {nombreArticulo}");
                writer.WriteLine($"Costo Promedio: {costoPromedio:C}");
            }
        }
    }

    static void ActualizarCantidadProducida(string nombreArchivo, int nuevaCantidadProducida)
    {
        // Leer el contenido del archivo
        string[] lineas = File.ReadAllLines(nombreArchivo);

        // Actualizar la cantidad producida en la segunda línea del archivo
        lineas[1] = $"Cantidad producida: {nuevaCantidadProducida}";

        // Escribir las líneas actualizadas en el archivo
        File.WriteAllLines(nombreArchivo, lineas);
    }

    static void BorrarArticulo(string nombreArchivo)
    {
        // Borrar el archivo si existe
        if (File.Exists(nombreArchivo))
        {
            File.Delete(nombreArchivo);
        }
    }
}
