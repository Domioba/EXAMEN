﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;

public class DatoEstadistico
{
    public int Id { get; set; }
    public string Nombre { get; set; }
    public List<double> Valores { get; set; }
}

public class GestionDatosEstadisticos
{
    private List<DatoEstadistico> datos;

    public GestionDatosEstadisticos()
    {
        datos = new List<DatoEstadistico>();
    }

    public void AgregarDato(DatoEstadistico dato)
    {
        datos.Add(dato);
    }

    public void MostrarDatos()
    {
        Console.WriteLine("Listado de Datos Estadísticos:");
        foreach (var dato in datos)
        {
            Console.WriteLine($"ID: {dato.Id}, Nombre: {dato.Nombre}, Valores: [{string.Join(", ", dato.Valores)}]");
        }
    }

    public void ActualizarDato(int id, DatoEstadistico datoActualizado)
    {
        var datoExistente = datos.Find(d => d.Id == id);
        if (datoExistente != null)
        {
            datoExistente.Nombre = datoActualizado.Nombre;
            datoExistente.Valores = datoActualizado.Valores;
            Console.WriteLine("Dato estadístico actualizado correctamente.");
        }
        else
        {
            Console.WriteLine("Dato estadístico no encontrado.");
        }
    }

    public void EliminarDato(int id)
    {
        var datoExistente = datos.Find(d => d.Id == id);
        if (datoExistente != null)
        {
            datos.Remove(datoExistente);
            Console.WriteLine("Dato estadístico eliminado correctamente.");
        }
        else
        {
            Console.WriteLine("Dato estadístico no encontrado.");
        }
    }

    public double CalcularMedia(int id)
    {
        var dato = datos.Find(d => d.Id == id);
        if (dato != null)
        {
            return dato.Valores.Average();
        }
        else
        {
            Console.WriteLine("Dato estadístico no encontrado.");
            return 0;
        }
    }
}

class Program
{
    static void Main(string[] args)
    {
        Thread t = new Thread(metedohilo1);
        t.Start();
        t.Join();
        Thread t2 = new Thread(metedohilo2);
        t2.Start();
        t2.Join();
        Thread t3 = new Thread(metedohilo3);
        t3.Start();
        t3.Join();
    }

    static void metedohilo1()
    {
        GestionDatosEstadisticos gestionDatos = new GestionDatosEstadisticos();

        // Solicitar al usuario los detalles del primer dato
        Console.WriteLine("Ingrese los detalles del primer dato:");
        Console.Write("ID: ");
        int id1 = int.Parse(Console.ReadLine());
        Console.Write("Nombre: ");
        string nombre1 = Console.ReadLine();
        Console.WriteLine("Ingrese los valores (separados por coma):");
        string valores1Input = Console.ReadLine();
        List<double> valores1 = valores1Input.Split(',').Select(double.Parse).ToList();

        // Agregar dato con los detalles proporcionados
        gestionDatos.AgregarDato(new DatoEstadistico { Id = id1, Nombre = nombre1, Valores = valores1 });

        // Solicitar al usuario los detalles del segundo dato
        Console.WriteLine("Ingrese los detalles del segundo dato:");
        Console.Write("ID: ");
        int id2 = int.Parse(Console.ReadLine());
        Console.Write("Nombre: ");
        string nombre2 = Console.ReadLine();
        Console.WriteLine("Ingrese los valores (separados por coma):");
        string valores2Input = Console.ReadLine();
        List<double> valores2 = valores2Input.Split(',').Select(double.Parse).ToList();

        // Agregar dato con los detalles proporcionados
        gestionDatos.AgregarDato(new DatoEstadistico { Id = id2, Nombre = nombre2, Valores = valores2 });

        // Mostrar datos
        gestionDatos.MostrarDatos();

        // Actualizar dato
        gestionDatos.ActualizarDato(id2, new DatoEstadistico { Nombre = "Pesos", Valores = new List<double> { 60, 65, 70, 75, 80 } });

        // Mostrar datos después de la actualización
        gestionDatos.MostrarDatos();

        // Calcular media de un dato
        double mediaEdades = gestionDatos.CalcularMedia(1);
        Console.WriteLine($"Media de edades: {mediaEdades}");

        // Eliminar dato
        gestionDatos.EliminarDato(1);

        // Mostrar datos después de la eliminación
        gestionDatos.MostrarDatos();
    }

    static void metedohilo2()
    {
        GestionDatosEstadisticos gestionDatos = new GestionDatosEstadisticos();

        // Solicitar al usuario los detalles del tercer dato
        Console.WriteLine("Ingrese los detalles del tercer dato:");
        Console.Write("ID: ");
        int id3 = int.Parse(Console.ReadLine());
        Console.Write("Nombre: ");
        string nombre3 = Console.ReadLine();
        Console.WriteLine("Ingrese los valores (separados por coma):");
        string valores3Input = Console.ReadLine();
        List<double> valores3 = valores3Input.Split(',').Select(double.Parse).ToList();

        // Agregar dato con los detalles proporcionados
        gestionDatos.AgregarDato(new DatoEstadistico { Id = id3, Nombre = nombre3, Valores = valores3 });

        // Mostrar datos
        gestionDatos.MostrarDatos();
    }

    static void metedohilo3()
    {
        GestionDatosEstadisticos gestionDatos = new GestionDatosEstadisticos();

        // Realizar algún cálculo adicional (simulación)
        double mediaPrecios = gestionDatos.CalcularMedia(3);
        Console.WriteLine($"Media de precios: {mediaPrecios}");
    }
}


